package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import bean.BankBean;
import bean.BankTransaction;

public class BankDao implements BankDaoI {

	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	BankBean bank = new BankBean();

	@Override
	public boolean checkAccount(long accNo) throws ClassNotFoundException, SQLException {

		boolean res = false;

		String query = "Select * from bank where accountno = ?";
		con = BankDB.getConnection();
		ps = con.prepareStatement(query);
		ps.setLong(1, accNo);
		rs = ps.executeQuery();

		if (rs.next()) {
			res = false;
		} else {
			res = true;
		}
		return res;
	}

	@Override
	public void InsertData(long accNo, BankBean bean) throws ClassNotFoundException, SQLException {

		con = BankDB.getConnection();
		ps = con.prepareStatement("Insert into bank values (?,?,?,?,?,?)");

		ps.setString(1, bean.getName());
		ps.setLong(2, bean.getAccNo());
		ps.setLong(3, bean.getPin());
		ps.setString(4, bean.getAdd());
		ps.setString(5, bean.getPhone());
		ps.setInt(6, bean.getBalance());

		int r = ps.executeUpdate();

		if (r == 0) {
			System.out.println("Not inserted");
		} else {
			System.out.println("Value inserted");
		}
	}

	@Override
	public void updateData(BankBean bean) throws ClassNotFoundException, SQLException {

		con = BankDB.getConnection();
		ps = con.prepareStatement("Update bank set balance = ? where accountno = ?");
		ps.setInt(1, bean.getBalance());
		ps.setLong(2, bean.getAccNo());

		int r = ps.executeUpdate();

		if (r == 0) {
			System.out.println("Cannot update");
		} else {
			System.out.println("Updated");
		}
	}

	@Override
	public BankBean getAccountDetails(long accNo) throws ClassNotFoundException, SQLException {
		boolean res = false;

		String query = "Select * from bank where accountno = ?";
		con = BankDB.getConnection();
		ps = con.prepareStatement(query);
		ps.setLong(1, accNo);
		rs = ps.executeQuery();

		if (rs.next()) {
			bank.setName(rs.getString(1));
			bank.setAccNo(rs.getLong(2));
			bank.setPin(rs.getInt(3));
			bank.setAdd(rs.getString(4));
			bank.setPhone(rs.getString(5));
			bank.setBalance(rs.getInt(6));
		} else {
			bank = null;
		}
		return bank;
	}

	@Override
	public void setTransactions(BankTransaction trans) throws ClassNotFoundException, SQLException {

		String query = "Insert into transactions values (?,?,?,?)";
		con = BankDB.getConnection();
		ps = con.prepareStatement(query);
		ps.setString(1, trans.getType());
		ps.setLong(2, trans.getAccNo());
		ps.setInt(3, trans.getAmount());
		ps.setInt(4, trans.getTransaction_id());

		int res = ps.executeUpdate();

		if (res == 0) {
			System.out.println("Cannot insert");
		} else {
			System.out.println("Updated ");
		}

	}

	@Override
	public BankTransaction getTransactions(long accNo) throws ClassNotFoundException, SQLException {

		BankTransaction trans = new BankTransaction();
		String query = "Select * from transactions where accountno = ?";
		con = BankDB.getConnection();
		ps = con.prepareStatement(query);
		ps.setLong(1, accNo);

		rs = ps.executeQuery();

		if (rs.next()) {
			trans.setType(rs.getString(1));
			trans.setAccNo(rs.getLong(2));
			trans.setAmount(rs.getInt(3));
			trans.setTransaction_id(rs.getInt(4));
		}
		return trans;
	}

}
