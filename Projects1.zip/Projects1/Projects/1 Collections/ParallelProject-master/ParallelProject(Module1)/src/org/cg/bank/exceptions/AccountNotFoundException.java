package org.cg.bank.exceptions;

@SuppressWarnings("serial")
public class AccountNotFoundException extends Exception {

	public AccountNotFoundException() {

	}

	public String toString() {

		return "Account Not Found. \t  Enter a valid Account Number!!!";
	}

}
