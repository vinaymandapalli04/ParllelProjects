package org.cg.bank.bean;

public class Bank {

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public Bank(String name2, int accNo2, int pin2, String dob2, String add2, String phone2, int bal) {
		super();
	}

	public Bank() {
		
	}

	private String name;
	private long accNumber;
	private int pin;
	private String add;
	private String phoneNum;
	private int balance;

	String trans = new String();

	public String getTrans() {
		return trans;
	}

	public void setTrans(String string) {
		trans = string;
	}

	public int getBalance() {
		return balance;
	}

	public int setBalance(int balance) {
		return this.balance = balance;
	}

	public String getPhone() {
		return phoneNum;
	}

	@Override
	public String toString() {
		return "AccountDetails name =" + name + "\n accNo =" + accNumber + "\n pin =" + pin + "\n add =" + add
				+ "\n phone =" + phoneNum + "\nbalance =" + balance;
	}

	public void setPhone(String phone2) {
		this.phoneNum = phone2;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAccNo() {
		return accNumber;
	}

	public long setAccNo(long accNo2) {
		return this.accNumber = accNo2;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

}
