package org.cg.bank.exceptions;

@SuppressWarnings("serial")
public class MinimumBalanceException extends Exception {

	@Override
	public String toString() {

		return "Minimum Balance should be 200";
	}

	public MinimumBalanceException() {

	}
}
