package org.cg.bank.exceptions;

@SuppressWarnings("serial")
public class InsufficientBalanceException extends Exception {

	public InsufficientBalanceException() {

	}

	@Override
	public String toString() {
		return " Balance \n Operation Cannot be processed";
	}

}
