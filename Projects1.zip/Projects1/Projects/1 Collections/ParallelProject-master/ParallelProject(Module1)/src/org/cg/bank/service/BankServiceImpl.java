package org.cg.bank.service;

import java.util.List;

import org.cg.bank.bean.Bank;
import org.cg.bank.dao.BankDaoImpl;
import org.cg.bank.dao.BankDaoI;
import org.cg.bank.exceptions.*;

public class BankServiceImpl implements BankServiceI {

	BankDaoI dao = new BankDaoImpl();
	Bank ba = new Bank();
	Bank ba1 = new Bank();

	boolean res;

	// to get the details if account exists or not and add account

	public boolean createAccount(String name, String add, long accNo, String phone, int pin, int bal)
			throws AccountAlreadyExistsException {

		Bank b = new Bank();
		boolean res = false;

		if (dao.checkAccount(accNo) == null) {

			b.setAccNo(accNo);
			b.setAdd(add);
			b.setBalance(bal);
			b.setName(name);
			b.setPhone(phone);
			b.setPin(pin);
			b.setTrans("Account Created with Balance  : " + bal + "\n");

			dao.setData(accNo, b);

			res = true;
		}

		else

		{
			res = false;
			throw new AccountAlreadyExistsException();
		}
		return res;

	}

	// to show balance

	public int showBalance(long accNo) throws AccountNotFoundException {

		ba = dao.checkAccount(accNo);
		int balance = 0;
		if (ba == null) {
			throw new AccountNotFoundException();
		} else {
			balance = ba.getBalance();
		}

		return balance;
	}

	// to deposit

	public int deposit(long accNo, int deposit_amount) throws AccountNotFoundException {

		int balance = 0;
		ba = dao.checkAccount(accNo);

		if (ba == null) {
			throw new AccountNotFoundException();
		} else {

			balance = ba.setBalance(ba.getBalance() + deposit_amount);
			String s = ba.getTrans() + "Amount deposited :" + deposit_amount + "\n";
			ba.setTrans(s);
			dao.setData(accNo, ba);
		}

		return balance;
	}

	// to withdraw

	public int withdraw(long accNo, int withdraw_amount) throws AccountNotFoundException, InsufficientBalanceException {

		int balance = 0;
		ba = dao.checkAccount(accNo);
		if (ba == null) {
			throw new AccountNotFoundException();
		} else {
			if (ba.getBalance() > withdraw_amount) {
				balance = ba.setBalance(ba.getBalance() - withdraw_amount);
				String s = ba.getTrans() + "Amount withdrawn :" + withdraw_amount + "\n";
				ba.setTrans(s);
			} else {
				throw new InsufficientBalanceException();
			}
			dao.setData(accNo, ba);
		}

		return balance;
	}

	// to transfer fund

	public boolean transferfund(long accNo, long accNo1, int transfer_amount)
			throws AccountNotFoundException, InsufficientBalanceException {

		ba = dao.checkAccount(accNo);

		if (!(ba == null)) {

			ba1 = dao.checkAccount(accNo1);

			if (!(ba1 == null))

			{

				int senderbal = ba.getBalance();

				if (senderbal > transfer_amount) {
					int recieverbal = ba1.getBalance();

					ba.setBalance(senderbal - transfer_amount);
					ba1.setBalance(recieverbal + transfer_amount);
					String s = ba.getTrans() + "Transferred to  :" + accNo1 + " Amount : " + transfer_amount + "\n";
					ba.setTrans(s);
					String s1 = ba1.getTrans() + "Transferred from  :" + accNo + " Amount : " + transfer_amount
							+ "\n";
					ba1.setTrans(s1);
					dao.setData(accNo, ba);
					dao.setData(accNo1, ba1);
				} else {
					throw new InsufficientBalanceException();
				}
			}

			else {
				throw new AccountNotFoundException();
			}
		} else {
			throw new AccountNotFoundException();
		}

		return true;
	}

	// to validate the Balance

	public boolean validateBalance(long accNo, int amount) throws InsufficientBalanceException

	{
		ba = dao.checkAccount(accNo);
		if (ba == null) {
			throw new InsufficientBalanceException();
		} else {
			return true;
		}
	}

	// to set transactions

	public String setTrans(long accNo) throws AccountNotFoundException {

		ba = dao.checkAccount(accNo);
		String s;

		if (ba == null) {
			throw new AccountNotFoundException();
		} else {
			s = ba.getTrans();
		}
		return s;
	}

	@Override
	public List<Bank> getAllAccounts() {
		return dao.getAllBankAccounts();
	}

}
