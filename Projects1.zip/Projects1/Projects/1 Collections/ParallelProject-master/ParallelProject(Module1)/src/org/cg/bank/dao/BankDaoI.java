package org.cg.bank.dao;

import java.util.List;

import org.cg.bank.bean.Bank;

public interface BankDaoI {

	public Bank checkAccount(long accNo);

	public void setData(long accNo, Bank bean);
	
	public List<Bank> getAllBankAccounts();

}
